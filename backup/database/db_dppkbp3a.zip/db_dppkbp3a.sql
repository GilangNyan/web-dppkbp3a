SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: albums
#

DROP TABLE IF EXISTS `albums`;

CREATE TABLE `albums` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `album_title` varchar(255) NOT NULL,
  `album_description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: halaman
#

DROP TABLE IF EXISTS `halaman`;

CREATE TABLE `halaman` (
  `id_halaman` varchar(255) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `slug` varchar(150) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_halaman`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: kepala_dinas
#

DROP TABLE IF EXISTS `kepala_dinas`;

CREATE TABLE `kepala_dinas` (
  `id` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jabatan` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `sambutan` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `kepala_dinas` (`id`, `nama`, `jabatan`, `foto`, `sambutan`) VALUES ('1', 'Dra. Hj. Nunung Kartini, M.Pd', 'Kepala Dinas', '1.jpg', 'Isi dengan sambutan kepala dinas.');


#
# TABLE STRUCTURE FOR: komentar
#

DROP TABLE IF EXISTS `komentar`;

CREATE TABLE `komentar` (
  `id` varchar(255) NOT NULL,
  `display_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `id_post` varchar(255) NOT NULL,
  `id_parent` varchar(255) DEFAULT NULL,
  `komentar` text NOT NULL,
  `is_mod` int(10) unsigned NOT NULL,
  `id_mod` varchar(255) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `komentar` (`id`, `display_name`, `email`, `id_post`, `id_parent`, `komentar`, `is_mod`, `id_mod`, `tanggal`) VALUES ('comment-5d92098cc1acc', 'Super Admin', 'admin@gmail.com', 'post-5d92083e47112', NULL, 'Komentar kuy', 1, '1', '2019-09-30 20:56:28');


#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id_menu` varchar(255) NOT NULL,
  `nama_menu` varchar(150) NOT NULL,
  `posisi` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`version`) VALUES ('13');


#
# TABLE STRUCTURE FOR: pesan
#

DROP TABLE IF EXISTS `pesan`;

CREATE TABLE `pesan` (
  `id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `dibaca` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: photos
#

DROP TABLE IF EXISTS `photos`;

CREATE TABLE `photos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `photo_album_id` bigint(20) unsigned NOT NULL,
  `photo_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: post
#

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `id` varchar(255) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `slug` varchar(150) NOT NULL,
  `image` varchar(40) NOT NULL DEFAULT 'post_default.jpg',
  `author` varchar(255) NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `views` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `post` (`id`, `judul`, `isi`, `tanggal`, `slug`, `image`, `author`, `status`, `views`) VALUES ('post-5d92083e47112', 'Tulisan 1', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In dictum non consectetur a erat. Tellus elementum sagittis vitae et leo duis ut diam quam. Dignissim diam quis enim lobortis scelerisque fermentum. Libero nunc consequat interdum varius. At varius vel pharetra vel turpis nunc. Mi in nulla posuere sollicitudin aliquam ultrices sagittis orci a. Augue ut lectus arcu bibendum at varius. Quis auctor elit sed vulputate mi sit amet mauris. Habitant morbi tristique senectus et netus et malesuada. Enim neque volutpat ac tincidunt vitae semper quis lectus. Vestibulum rhoncus est pellentesque elit ullamcorper dignissim cras tincidunt lobortis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Sit amet purus gravida quis. Tellus in hac habitasse platea dictumst vestibulum.</p>\r\n\r\n<p>Morbi blandit cursus risus at ultrices. In fermentum posuere urna nec. Euismod lacinia at quis risus sed vulputate odio ut enim. Condimentum id venenatis a condimentum vitae sapien pellentesque habitant. Amet justo donec enim diam vulputate. Egestas sed tempus urna et pharetra pharetra massa. Odio aenean sed adipiscing diam donec adipiscing tristique. Arcu bibendum at varius vel pharetra vel. Egestas tellus rutrum tellus pellentesque eu. Mi tempus imperdiet nulla malesuada pellentesque. Gravida neque convallis a cras semper auctor neque vitae. Aliquet sagittis id consectetur purus ut. Pharetra convallis posuere morbi leo urna molestie. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>', '2019-09-30 20:50:54', 'tulisan-1.html', 'post-5d92083e47112.jpg', '1', 1, 3);
INSERT INTO `post` (`id`, `judul`, `isi`, `tanggal`, `slug`, `image`, `author`, `status`, `views`) VALUES ('post-5d9208511fe09', 'Tulisan 2', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In dictum non consectetur a erat. Tellus elementum sagittis vitae et leo duis ut diam quam. Dignissim diam quis enim lobortis scelerisque fermentum. Libero nunc consequat interdum varius. At varius vel pharetra vel turpis nunc. Mi in nulla posuere sollicitudin aliquam ultrices sagittis orci a. Augue ut lectus arcu bibendum at varius. Quis auctor elit sed vulputate mi sit amet mauris. Habitant morbi tristique senectus et netus et malesuada. Enim neque volutpat ac tincidunt vitae semper quis lectus. Vestibulum rhoncus est pellentesque elit ullamcorper dignissim cras tincidunt lobortis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Sit amet purus gravida quis. Tellus in hac habitasse platea dictumst vestibulum.</p>\r\n\r\n<p>Morbi blandit cursus risus at ultrices. In fermentum posuere urna nec. Euismod lacinia at quis risus sed vulputate odio ut enim. Condimentum id venenatis a condimentum vitae sapien pellentesque habitant. Amet justo donec enim diam vulputate. Egestas sed tempus urna et pharetra pharetra massa. Odio aenean sed adipiscing diam donec adipiscing tristique. Arcu bibendum at varius vel pharetra vel. Egestas tellus rutrum tellus pellentesque eu. Mi tempus imperdiet nulla malesuada pellentesque. Gravida neque convallis a cras semper auctor neque vitae. Aliquet sagittis id consectetur purus ut. Pharetra convallis posuere morbi leo urna molestie. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>', '2019-09-30 20:51:13', 'tulisan-2.html', 'post-5d9208511fe09.jpg', '1', 1, 0);
INSERT INTO `post` (`id`, `judul`, `isi`, `tanggal`, `slug`, `image`, `author`, `status`, `views`) VALUES ('post-5d92086561b11', 'Tulisan 3', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In dictum non consectetur a erat. Tellus elementum sagittis vitae et leo duis ut diam quam. Dignissim diam quis enim lobortis scelerisque fermentum. Libero nunc consequat interdum varius. At varius vel pharetra vel turpis nunc. Mi in nulla posuere sollicitudin aliquam ultrices sagittis orci a. Augue ut lectus arcu bibendum at varius. Quis auctor elit sed vulputate mi sit amet mauris. Habitant morbi tristique senectus et netus et malesuada. Enim neque volutpat ac tincidunt vitae semper quis lectus. Vestibulum rhoncus est pellentesque elit ullamcorper dignissim cras tincidunt lobortis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Sit amet purus gravida quis. Tellus in hac habitasse platea dictumst vestibulum.</p>\r\n\r\n<p>Morbi blandit cursus risus at ultrices. In fermentum posuere urna nec. Euismod lacinia at quis risus sed vulputate odio ut enim. Condimentum id venenatis a condimentum vitae sapien pellentesque habitant. Amet justo donec enim diam vulputate. Egestas sed tempus urna et pharetra pharetra massa. Odio aenean sed adipiscing diam donec adipiscing tristique. Arcu bibendum at varius vel pharetra vel. Egestas tellus rutrum tellus pellentesque eu. Mi tempus imperdiet nulla malesuada pellentesque. Gravida neque convallis a cras semper auctor neque vitae. Aliquet sagittis id consectetur purus ut. Pharetra convallis posuere morbi leo urna molestie. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>', '2019-09-30 20:51:33', 'tulisan-3.html', 'post-5d92086561b11.png', '1', 1, 1);
INSERT INTO `post` (`id`, `judul`, `isi`, `tanggal`, `slug`, `image`, `author`, `status`, `views`) VALUES ('post-5d9208a2b0fa5', 'Tulisan 4', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In dictum non consectetur a erat. Tellus elementum sagittis vitae et leo duis ut diam quam. Dignissim diam quis enim lobortis scelerisque fermentum. Libero nunc consequat interdum varius. At varius vel pharetra vel turpis nunc. Mi in nulla posuere sollicitudin aliquam ultrices sagittis orci a. Augue ut lectus arcu bibendum at varius. Quis auctor elit sed vulputate mi sit amet mauris. Habitant morbi tristique senectus et netus et malesuada. Enim neque volutpat ac tincidunt vitae semper quis lectus. Vestibulum rhoncus est pellentesque elit ullamcorper dignissim cras tincidunt lobortis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Sit amet purus gravida quis. Tellus in hac habitasse platea dictumst vestibulum.</p>\r\n\r\n<p>Morbi blandit cursus risus at ultrices. In fermentum posuere urna nec. Euismod lacinia at quis risus sed vulputate odio ut enim. Condimentum id venenatis a condimentum vitae sapien pellentesque habitant. Amet justo donec enim diam vulputate. Egestas sed tempus urna et pharetra pharetra massa. Odio aenean sed adipiscing diam donec adipiscing tristique. Arcu bibendum at varius vel pharetra vel. Egestas tellus rutrum tellus pellentesque eu. Mi tempus imperdiet nulla malesuada pellentesque. Gravida neque convallis a cras semper auctor neque vitae. Aliquet sagittis id consectetur purus ut. Pharetra convallis posuere morbi leo urna molestie. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>', '2019-09-30 20:52:34', 'tulisan-4.html', 'post-5d9208a2b0fa5.png', '1', 1, 1);
INSERT INTO `post` (`id`, `judul`, `isi`, `tanggal`, `slug`, `image`, `author`, `status`, `views`) VALUES ('post-5d9208b45e2cb', 'Tulisan 5', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In dictum non consectetur a erat. Tellus elementum sagittis vitae et leo duis ut diam quam. Dignissim diam quis enim lobortis scelerisque fermentum. Libero nunc consequat interdum varius. At varius vel pharetra vel turpis nunc. Mi in nulla posuere sollicitudin aliquam ultrices sagittis orci a. Augue ut lectus arcu bibendum at varius. Quis auctor elit sed vulputate mi sit amet mauris. Habitant morbi tristique senectus et netus et malesuada. Enim neque volutpat ac tincidunt vitae semper quis lectus. Vestibulum rhoncus est pellentesque elit ullamcorper dignissim cras tincidunt lobortis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Sit amet purus gravida quis. Tellus in hac habitasse platea dictumst vestibulum.</p>\r\n\r\n<p>Morbi blandit cursus risus at ultrices. In fermentum posuere urna nec. Euismod lacinia at quis risus sed vulputate odio ut enim. Condimentum id venenatis a condimentum vitae sapien pellentesque habitant. Amet justo donec enim diam vulputate. Egestas sed tempus urna et pharetra pharetra massa. Odio aenean sed adipiscing diam donec adipiscing tristique. Arcu bibendum at varius vel pharetra vel. Egestas tellus rutrum tellus pellentesque eu. Mi tempus imperdiet nulla malesuada pellentesque. Gravida neque convallis a cras semper auctor neque vitae. Aliquet sagittis id consectetur purus ut. Pharetra convallis posuere morbi leo urna molestie. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>', '2019-09-30 20:52:52', 'tulisan-5.html', 'post-5d9208b45e2cb.png', '1', 1, 0);
INSERT INTO `post` (`id`, `judul`, `isi`, `tanggal`, `slug`, `image`, `author`, `status`, `views`) VALUES ('post-5d9208fa54e0b', 'Tulisan 6', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In dictum non consectetur a erat. Tellus elementum sagittis vitae et leo duis ut diam quam. Dignissim diam quis enim lobortis scelerisque fermentum. Libero nunc consequat interdum varius. At varius vel pharetra vel turpis nunc. Mi in nulla posuere sollicitudin aliquam ultrices sagittis orci a. Augue ut lectus arcu bibendum at varius. Quis auctor elit sed vulputate mi sit amet mauris. Habitant morbi tristique senectus et netus et malesuada. Enim neque volutpat ac tincidunt vitae semper quis lectus. Vestibulum rhoncus est pellentesque elit ullamcorper dignissim cras tincidunt lobortis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Sit amet purus gravida quis. Tellus in hac habitasse platea dictumst vestibulum.</p>\r\n\r\n<p>Morbi blandit cursus risus at ultrices. In fermentum posuere urna nec. Euismod lacinia at quis risus sed vulputate odio ut enim. Condimentum id venenatis a condimentum vitae sapien pellentesque habitant. Amet justo donec enim diam vulputate. Egestas sed tempus urna et pharetra pharetra massa. Odio aenean sed adipiscing diam donec adipiscing tristique. Arcu bibendum at varius vel pharetra vel. Egestas tellus rutrum tellus pellentesque eu. Mi tempus imperdiet nulla malesuada pellentesque. Gravida neque convallis a cras semper auctor neque vitae. Aliquet sagittis id consectetur purus ut. Pharetra convallis posuere morbi leo urna molestie. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>', '2019-09-30 20:54:02', 'tulisan-6.html', 'post-5d9208fa54e0b.jpg', '1', 1, 0);
INSERT INTO `post` (`id`, `judul`, `isi`, `tanggal`, `slug`, `image`, `author`, `status`, `views`) VALUES ('post-5d920911262db', 'Tulisan 7', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In dictum non consectetur a erat. Tellus elementum sagittis vitae et leo duis ut diam quam. Dignissim diam quis enim lobortis scelerisque fermentum. Libero nunc consequat interdum varius. At varius vel pharetra vel turpis nunc. Mi in nulla posuere sollicitudin aliquam ultrices sagittis orci a. Augue ut lectus arcu bibendum at varius. Quis auctor elit sed vulputate mi sit amet mauris. Habitant morbi tristique senectus et netus et malesuada. Enim neque volutpat ac tincidunt vitae semper quis lectus. Vestibulum rhoncus est pellentesque elit ullamcorper dignissim cras tincidunt lobortis. Odio facilisis mauris sit amet massa vitae tortor condimentum lacinia. Sit amet purus gravida quis. Tellus in hac habitasse platea dictumst vestibulum.</p>\r\n\r\n<p>Morbi blandit cursus risus at ultrices. In fermentum posuere urna nec. Euismod lacinia at quis risus sed vulputate odio ut enim. Condimentum id venenatis a condimentum vitae sapien pellentesque habitant. Amet justo donec enim diam vulputate. Egestas sed tempus urna et pharetra pharetra massa. Odio aenean sed adipiscing diam donec adipiscing tristique. Arcu bibendum at varius vel pharetra vel. Egestas tellus rutrum tellus pellentesque eu. Mi tempus imperdiet nulla malesuada pellentesque. Gravida neque convallis a cras semper auctor neque vitae. Aliquet sagittis id consectetur purus ut. Pharetra convallis posuere morbi leo urna molestie. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum.</p>', '2019-09-30 20:54:25', 'tulisan-7.html', 'post-5d920911262db.jpg', '1', 1, 1);


#
# TABLE STRUCTURE FOR: profil
#

DROP TABLE IF EXISTS `profil`;

CREATE TABLE `profil` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `namadinas` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `provinsi` int(10) unsigned DEFAULT NULL,
  `kabupaten` int(10) unsigned DEFAULT NULL,
  `kecamatan` int(10) unsigned DEFAULT NULL,
  `desa` int(10) unsigned DEFAULT NULL,
  `telepon` varchar(13) NOT NULL,
  `kodepos` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `profil` (`id`, `namadinas`, `alamat`, `provinsi`, `kabupaten`, `kecamatan`, `desa`, `telepon`, `kodepos`) VALUES (1, 'Dinas Pengendalian Penduduk Keluarga Berencana Pemberdayaan Perempuan dan Perlindungan Anak', 'Jl. Yudanegara', 32, 3278, 3278050, 3278050004, '0265000000', '12345');


#
# TABLE STRUCTURE FOR: tokens
#

DROP TABLE IF EXISTS `tokens`;

CREATE TABLE `tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `username` varchar(18) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `role` varchar(10) NOT NULL DEFAULT 'USER',
  `dibuat_pada` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id`, `nama`, `username`, `email`, `password`, `image`, `role`, `dibuat_pada`) VALUES ('1', 'Super Admin', 'admin', 'admin@gmail.com', '$2y$10$w.BLc6zKtEbRtpTEMO1GceNChW4SUfCaKseg0KUtt6B/Wwt0HqRIC', 'default.jpg', 'GOD', '2019-09-17 22:56:52');


#
# TABLE STRUCTURE FOR: video
#

DROP TABLE IF EXISTS `video`;

CREATE TABLE `video` (
  `id` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `diupload` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: visitor
#

DROP TABLE IF EXISTS `visitor`;

CREATE TABLE `visitor` (
  `ip` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  `online` int(11) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `platform` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-09-17', 1, 1568735987, 'Chrome', 'Windows 10');
INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-09-18', 1, 1568816318, 'Chrome', 'Windows 10');
INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-09-30', 6, 1569851723, 'Chrome', 'Windows 10');


SET foreign_key_checks = 1;
