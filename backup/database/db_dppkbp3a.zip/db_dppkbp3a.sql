SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: albums
#

DROP TABLE IF EXISTS `albums`;

CREATE TABLE `albums` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `album_title` varchar(255) NOT NULL,
  `album_description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `albums` (`id`, `album_title`, `album_description`, `created_at`, `updated_at`) VALUES ('1', 'Test Album', 'Ini nyobain ngetes album ya bos', '2019-09-07 15:07:51', '2019-09-07 20:07:51');


#
# TABLE STRUCTURE FOR: halaman
#

DROP TABLE IF EXISTS `halaman`;

CREATE TABLE `halaman` (
  `id_halaman` varchar(255) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `slug` varchar(150) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_halaman`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: kepala_dinas
#

DROP TABLE IF EXISTS `kepala_dinas`;

CREATE TABLE `kepala_dinas` (
  `id` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jabatan` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `sambutan` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `kepala_dinas` (`id`, `nama`, `jabatan`, `foto`, `sambutan`) VALUES ('1', 'Nama Kepala Dinas', 'Kepala Dinas', 'default.jpg', 'Isikan dengan sambutan kepala dinas.');


#
# TABLE STRUCTURE FOR: komentar
#

DROP TABLE IF EXISTS `komentar`;

CREATE TABLE `komentar` (
  `id` varchar(255) NOT NULL,
  `display_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `id_post` varchar(255) NOT NULL,
  `id_parent` varchar(255) DEFAULT NULL,
  `komentar` text NOT NULL,
  `is_mod` int(10) unsigned NOT NULL,
  `id_mod` varchar(255) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id_menu` varchar(255) NOT NULL,
  `nama_menu` varchar(150) NOT NULL,
  `posisi` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`version`) VALUES ('12');


#
# TABLE STRUCTURE FOR: pesan
#

DROP TABLE IF EXISTS `pesan`;

CREATE TABLE `pesan` (
  `id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `dibaca` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: photos
#

DROP TABLE IF EXISTS `photos`;

CREATE TABLE `photos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `photo_album_id` bigint(20) unsigned NOT NULL,
  `photo_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `photos` (`id`, `photo_album_id`, `photo_name`, `created_at`, `updated_at`) VALUES ('1', '1', '1_Test_Upload_Foto.jpg', '2019-09-08 15:45:35', '2019-09-08 15:45:35');
INSERT INTO `photos` (`id`, `photo_album_id`, `photo_name`, `created_at`, `updated_at`) VALUES ('2', '1', '1_Test_Upload_2.jpg', '2019-09-08 15:58:09', '2019-09-08 15:58:09');
INSERT INTO `photos` (`id`, `photo_album_id`, `photo_name`, `created_at`, `updated_at`) VALUES ('3', '1', '1_Test_Upload_3.jpg', '2019-09-08 15:58:41', '2019-09-08 15:58:41');
INSERT INTO `photos` (`id`, `photo_album_id`, `photo_name`, `created_at`, `updated_at`) VALUES ('4', '1', '1_Test_Upload_4.png', '2019-09-08 15:59:37', '2019-09-08 15:59:37');
INSERT INTO `photos` (`id`, `photo_album_id`, `photo_name`, `created_at`, `updated_at`) VALUES ('5', '1', '1_Test_Upload_5.jpg', '2019-09-08 16:00:38', '2019-09-08 16:00:38');


#
# TABLE STRUCTURE FOR: post
#

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `id` varchar(255) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `slug` varchar(150) NOT NULL,
  `image` varchar(40) NOT NULL DEFAULT 'post_default.jpg',
  `author` varchar(255) NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `views` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `post` (`id`, `judul`, `isi`, `tanggal`, `slug`, `image`, `author`, `status`, `views`) VALUES ('post-5d67c866e1ab6', 'Test Add Post', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Nec sagittis aliquam malesuada bibendum arcu. Massa tincidunt nunc pulvinar sapien et. Pretium nibh ipsum consequat nisl vel pretium lectus. Et malesuada fames ac turpis egestas maecenas pharetra. Cras ornare arcu dui vivamus. Enim tortor at auctor urna nunc. Augue interdum velit euismod in pellentesque massa placerat duis ultricies. Vulputate eu scelerisque felis imperdiet proin fermentum leo. Morbi blandit cursus risus at ultrices. Vitae tortor condimentum lacinia quis vel eros. Tempor id eu nisl nunc mi ipsum faucibus vitae aliquet. At varius vel pharetra vel turpis nunc eget lorem dolor. Ut consequat semper viverra nam libero justo laoreet sit amet.</p>\r\n\r\n<p>Tortor at auctor urna nunc id cursus metus aliquam eleifend. Vestibulum morbi blandit cursus risus at. In aliquam sem fringilla ut. Libero nunc consequat interdum varius sit. Interdum consectetur libero id faucibus nisl tincidunt eget nullam. Nunc vel risus commodo viverra maecenas accumsan lacus vel. Vitae aliquet nec ullamcorper sit amet risus. A arcu cursus vitae congue mauris. Pellentesque habitant morbi tristique senectus et netus et. Amet purus gravida quis blandit turpis cursus in. In cursus turpis massa tincidunt dui ut ornare lectus sit. Est ante in nibh mauris cursus mattis. Amet risus nullam eget felis. Elit eget gravida cum sociis natoque penatibus et magnis. Magna fringilla urna porttitor rhoncus dolor purus non enim praesent. A pellentesque sit amet porttitor eget. Diam maecenas sed enim ut sem viverra aliquet. Velit sed ullamcorper morbi tincidunt ornare massa eget egestas purus. Vitae turpis massa sed elementum tempus egestas sed sed risus. Viverra tellus in hac habitasse platea dictumst vestibulum.</p>\r\n\r\n<p>Aliquet enim tortor at auctor. Egestas erat imperdiet sed euismod nisi porta lorem. Ut etiam sit amet nisl purus in mollis. Diam ut venenatis tellus in metus vulputate eu scelerisque. In hac habitasse platea dictumst. Bibendum neque egestas congue quisque egestas diam in arcu. Magna eget est lorem ipsum dolor. Convallis convallis tellus id interdum velit laoreet id donec ultrices. Erat velit scelerisque in dictum non consectetur a erat. Tempor id eu nisl nunc mi ipsum faucibus vitae aliquet. Enim nulla aliquet porttitor lacus luctus accumsan tortor posuere. Posuere ac ut consequat semper viverra nam libero justo. Elementum facilisis leo vel fringilla est. Volutpat sed cras ornare arcu dui vivamus arcu felis. Eget egestas purus viverra accumsan in nisl nisi scelerisque. Ut enim blandit volutpat maecenas volutpat blandit aliquam etiam.</p>', '2019-08-29 19:43:18', 'test-add-post.html', 'post-5d67c866e1ab6.gif', '1', 1, 7);


#
# TABLE STRUCTURE FOR: tokens
#

DROP TABLE IF EXISTS `tokens`;

CREATE TABLE `tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (6, 'd2877b89377121f4c3b5e47c3a4644', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (7, '98089d73f670223cb3444e16e66027', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (8, '304085a3485659fdb2eb29b4ac7f8b', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (9, '03dc4187d2c1a44584488785b0e18d', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (10, 'edb855bef5a2f0cd3a71486ffedc5a', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (11, 'f592f7f8ccf7ba25afcba2b484dc55', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (12, 'ded8d3561d28b4ea4d9407f7f1b36c', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (13, 'f4ab1a3a7b62a59cd4ea95b0643cf2', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (14, '7a3a377f31b24bfc8aed99a9f24917', 'user-5d68a69fc859d', '2019-08-30');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (15, 'b32e32c02c704898b3719fa3dfc12b', 'user-5d68a69fc859d', '2019-08-31');
INSERT INTO `tokens` (`id`, `token`, `user_id`, `created`) VALUES (16, '7fe42e8f8b0095d3881284619487b7', 'user-5d68a69fc859d', '2019-08-31');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `username` varchar(18) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `role` varchar(10) NOT NULL DEFAULT 'USER',
  `dibuat_pada` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id`, `nama`, `username`, `email`, `password`, `image`, `role`, `dibuat_pada`) VALUES ('1', 'Super Admin', 'admin', 'admin@gmail.com', '$2y$10$oSa9o76IEydsuaoMcloxgenDvcymT/dpF1BZ0ii0ihMPMyFCrCxMm', 'default.jpg', 'GOD', '2019-08-29 11:23:37');
INSERT INTO `user` (`id`, `nama`, `username`, `email`, `password`, `image`, `role`, `dibuat_pada`) VALUES ('user-5d68a69fc859d', 'Gilang Saeful Anwar', 'Gilang', 'sagilang@gmail.com', '$2y$10$wkpK0lZp.hrwsVS0R/V5XOLbDaFxhDzpw/j82.MVwlhY9Eex3gb2i', 'default.jpg', 'ADMIN', '2019-08-30 11:31:27');


#
# TABLE STRUCTURE FOR: video
#

DROP TABLE IF EXISTS `video`;

CREATE TABLE `video` (
  `id` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `diupload` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `video` (`id`, `judul`, `deskripsi`, `filename`, `diupload`) VALUES ('vid-5d751f7c2e2cf', 'Test Upload Video 1', 'Test Upload Video 1', 'Test_Upload_Video_1.MP4', '2019-09-08 22:34:20');


#
# TABLE STRUCTURE FOR: visitor
#

DROP TABLE IF EXISTS `visitor`;

CREATE TABLE `visitor` (
  `ip` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  `online` int(11) NOT NULL,
  `browser` varchar(255) NOT NULL,
  `platform` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-08-29', 14, 1567098945, 'Chrome', 'Windows 10');
INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-08-30', 1, 1567126559, 'Chrome', 'Windows 10');
INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-08-31', 49, 1567270013, 'Chrome', 'Windows 10');
INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-09-01', 1, 1567324327, 'Chrome', 'Windows 10');
INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-09-03', 1, 1567520343, 'Chrome', 'Windows 10');
INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-09-07', 1, 1567861565, 'Chrome', 'Windows 10');
INSERT INTO `visitor` (`ip`, `tanggal`, `hits`, `online`, `browser`, `platform`) VALUES ('::1', '2019-09-08', 6, 1567947334, 'Chrome', 'Windows 10');


SET foreign_key_checks = 1;
